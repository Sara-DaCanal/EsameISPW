package test;
import static org.junit.Assert.assertEquals;

import org.junit.Test;

import logic.Email;

public class TestEmail {
	@Test
	public void testIsValidTrueCom() {
		//checking if a valid email is accepted
		String email = "sara@gmail.com";
		Email check = new Email(email);
		assertEquals(true, check.isValid());
	}
	@Test
	public void testIsValidTrueIt() {
		//checking if a valid email is accepted
		String email = "sara@gmail.it";
		Email check = new Email(email);
		assertEquals(true, check.isValid());
	}
	@Test
	public void testIsValidTrueEu() {
		//checking if a valid email is accepted
		String email = "sara@gmail.eu";
		Email check = new Email(email);
		assertEquals(true, check.isValid());
	}
	@Test
	public void testIsValidTooShort() {
		//checking if an email too short is rejected
		String email = "";
		Email check = new Email(email);
		assertEquals(false, check.isValid());
	}
	@Test
	public void testIsValidAtMissing() {
		//checking if an email too short is rejected
		String email = "sara.gmail.com";
		Email check = new Email(email);
		assertEquals(false, check.isValid());
	}
	@Test
	public void testisValidNoDomain() {
		//checking if an email with no domain is rejected
		String email = "sara@gmail";
		Email check = new Email(email);
		assertEquals(false, check.isValid());
	}
}
