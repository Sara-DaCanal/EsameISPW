package logic;

public class Email {
	private String email;
	public Email(String e) {
		this.email=e;
	}
	public boolean isValid() {
		//this method checks if an email is valid, but throws an undetected exception if the
		//parameter is null
		if(this.email.length()<6)
			return false;
		if(!this.email.contains("@"))
			return false;
		return (this.email.endsWith(".com") || this.email.endsWith(".it") || this.email.endsWith(".eu"));

	}
}
